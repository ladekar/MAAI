/* extern-pre-js.js must be prepended to the resulting sqlite3.js
   file. This file is currently only used for holding snippets during
   test and development.

   It gets its name from being used as the value for the
   --extern-pre-js=... Emscripten flag.
*/
